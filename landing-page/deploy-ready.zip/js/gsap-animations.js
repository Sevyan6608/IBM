/**
 * A1 Bulgaria IBM Landing Page - GSAP Animations
 * Includes: Smooth Scroll, Parallax, SplitText, and Inertia effects
 */

(function() {
    'use strict';

    // Wait for DOM to be fully loaded
    window.addEventListener('load', function() {

        // Register GSAP plugins
        gsap.registerPlugin(ScrollTrigger, Draggable);

        // Try to register SplitText if available
        if (typeof SplitText !== 'undefined') {
            gsap.registerPlugin(SplitText);
        }

        // ===================================
        // STICKY NAVBAR WITH HIDE/SHOW ON SCROLL
        // ===================================
        const header = document.querySelector('.header');
        let lastScrollY = 0;
        let ticking = false;

        ScrollTrigger.create({
            start: 'top -80',
            end: 99999,
            onUpdate: (self) => {
                const currentScrollY = self.scroll();

                if (!ticking) {
                    window.requestAnimationFrame(() => {
                        if (currentScrollY > lastScrollY && currentScrollY > 100) {
                            // Scrolling down - hide navbar
                            gsap.to(header, {
                                y: -100,
                                duration: 0.3,
                                ease: 'power2.out'
                            });
                        } else if (currentScrollY < lastScrollY) {
                            // Scrolling up - show navbar
                            gsap.to(header, {
                                y: 0,
                                duration: 0.3,
                                ease: 'power2.out'
                            });
                        }

                        lastScrollY = currentScrollY;
                        ticking = false;
                    });

                    ticking = true;
                }
            }
        });

        // ===================================
        // SPLIT TEXT FOR H2 ELEMENTS ONLY
        // ===================================
        if (typeof SplitText !== 'undefined') {
            const headings = document.querySelectorAll('h2');

            headings.forEach(heading => {
                // Split text into words
                const split = new SplitText(heading, {
                    type: 'words',
                    wordsClass: 'split-word'
                });

                // Animate words on scroll
                gsap.from(split.words, {
                    scrollTrigger: {
                        trigger: heading,
                        start: 'top 85%',
                        toggleActions: 'play none none none'
                    },
                    duration: 0.6,
                    opacity: 0,
                    y: 30,
                    rotationX: -90,
                    transformOrigin: '0% 50% -50',
                    stagger: 0.05,
                    ease: 'power2.out'
                });
            });
        } else {
            // Fallback: Simple fade-in animation for h2 headings
            const headings = document.querySelectorAll('h2');

            headings.forEach(heading => {
                gsap.from(heading, {
                    scrollTrigger: {
                        trigger: heading,
                        start: 'top 85%',
                        toggleActions: 'play none none none'
                    },
                    duration: 0.8,
                    opacity: 0,
                    y: 30,
                    ease: 'power2.out'
                });
            });
        }

        // ===================================
        // PRODUCTS SECTION ENTRANCE ANIMATION
        // ===================================
        const productCards = document.querySelectorAll('.product-card');

        productCards.forEach((card, index) => {
            // Card entrance animation
            gsap.from(card, {
                scrollTrigger: {
                    trigger: card,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                duration: 0.8,
                opacity: 0,
                y: 60,
                scale: 0.95,
                ease: 'power3.out'
            });
        });

        // ===================================
        // USP CARDS ENTRANCE ANIMATION
        // ===================================
        const uspGrid = document.querySelector('.usp-grid');
        const uspCards = document.querySelectorAll('.usp-card');

        if (uspGrid && uspCards.length > 0) {
            // Entrance animation for USP cards with stagger
            gsap.from(uspCards, {
                scrollTrigger: {
                    trigger: uspGrid,
                    start: 'top 75%',
                    toggleActions: 'play none none none'
                },
                duration: 0.7,
                opacity: 0,
                y: 50,
                scale: 0.9,
                stagger: 0.15,
                ease: 'back.out(1.2)'
            });
        }

        // ===================================
        // HERO SECTION ANIMATIONS (GRID LAYOUT)
        // ===================================
        const bannerMain = document.querySelector('.banner-main');
        const bannerSmall = document.querySelectorAll('.banner-small');

        if (bannerMain) {
            // Animate main banner (right side, spans 2 rows)
            gsap.from(bannerMain, {
                duration: 1.2,
                opacity: 0,
                scale: 0.95,
                x: 60,
                ease: 'power3.out',
                delay: 0.3
            });
        }

        if (bannerSmall.length > 0) {
            // Animate smaller banners (left side, stacked)
            gsap.from(bannerSmall, {
                duration: 0.8,
                opacity: 0,
                x: -40,
                y: 20,
                stagger: 0.2,
                ease: 'back.out(1.4)',
                delay: 0.5
            });
        }

        // ===================================
        // CHALLENGES & SOLUTIONS ANIMATION WITH PARALLAX
        // ===================================
        const challengesWrapper = document.querySelector('.challenges-solutions-wrapper');
        const challengesColumn = document.querySelector('.challenges-column');
        const solutionsColumn = document.querySelector('.solutions-column');

        // Parallax effect for the wrapper background
        if (challengesWrapper) {
            gsap.to(challengesWrapper, {
                scrollTrigger: {
                    trigger: challengesWrapper,
                    start: 'top bottom',
                    end: 'bottom top',
                    scrub: 1
                },
                backgroundPositionY: '20%',
                ease: 'none'
            });
        }

        if (challengesColumn) {
            gsap.from(challengesColumn, {
                scrollTrigger: {
                    trigger: challengesColumn,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                duration: 0.8,
                opacity: 0,
                x: -50,
                ease: 'power2.out'
            });
        }

        if (solutionsColumn) {
            gsap.from(solutionsColumn, {
                scrollTrigger: {
                    trigger: solutionsColumn,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                duration: 0.8,
                opacity: 0,
                x: 50,
                ease: 'power2.out'
            });
        }

        // ===================================
        // CONTACT FORM ANIMATION
        // ===================================
        const contactForm = document.querySelector('.contact-form-wrapper');
        const contactInfo = document.querySelector('.contact-info');

        if (contactForm) {
            gsap.from(contactForm, {
                scrollTrigger: {
                    trigger: contactForm,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                duration: 0.8,
                opacity: 0,
                y: 40,
                ease: 'power2.out'
            });
        }

        if (contactInfo) {
            gsap.from(contactInfo, {
                scrollTrigger: {
                    trigger: contactInfo,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                duration: 0.8,
                opacity: 0,
                y: 40,
                ease: 'power2.out',
                delay: 0.2
            });
        }

        // ===================================
        // FOOTER FADE IN
        // ===================================
        const footer = document.querySelector('.footer');

        if (footer) {
            gsap.from(footer, {
                scrollTrigger: {
                    trigger: footer,
                    start: 'top 90%',
                    toggleActions: 'play none none none'
                },
                duration: 1,
                opacity: 0,
                y: 30,
                ease: 'power2.out'
            });
        }

        // ===================================
        // REFRESH SCROLLTRIGGER ON RESIZE
        // ===================================
        let resizeTimer;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                ScrollTrigger.refresh();
            }, 250);
        });

    });

})();
