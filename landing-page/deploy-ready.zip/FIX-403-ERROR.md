# 🔧 Fix 403 Forbidden Error on translations.js

## The Problem

You're getting:
```
GET https://ibm.a1.bg/js/translations.js net::ERR_ABORTED 403 (Forbidden)
```

This means the server is **blocking access** to the file.

## ✅ Solution: Fix File Permissions

### Step 1: Check File Permissions

Via SSH or hosting file manager, check:
```bash
ls -la js/translations.js
```

Should show something like:
```
-rw-r--r-- 1 user group 31000 Nov 20 12:00 js/translations.js
```

### Step 2: Fix Permissions

If permissions are wrong, run:

```bash
# Fix the file
chmod 644 js/translations.js

# Fix all JS files
chmod 644 js/*.js

# Fix directories
chmod 755 js/
```

### Step 3: Fix ALL File Permissions

To fix everything at once:

```bash
# From your website root directory:

# Set correct permissions for directories
find . -type d -exec chmod 755 {} \;

# Set correct permissions for files
find . -type f -exec chmod 644 {} \;

# Make .htaccess readable
chmod 644 .htaccess
```

## 🔍 Other Possible Causes

### 1. ModSecurity Blocking

Some hosts have ModSecurity that blocks files. Check:
- cPanel → ModSecurity
- Look for blocked requests
- Whitelist `translations.js` if needed

### 2. Firewall Rules

Your host might have firewall rules blocking `.js` files:
- Contact hosting support
- Ask them to check firewall logs
- Provide the exact error message

### 3. Wrong File Ownership

Files might be owned by wrong user:

```bash
# Check ownership
ls -la js/

# Should show your username
# If it shows 'root' or another user, fix it:
chown -R yourusername:yourusername js/
```

## 🎯 Quick Fix Commands

Copy and paste these commands via SSH:

```bash
# Navigate to your website root
cd /path/to/public_html/

# Fix all permissions
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;

# Verify translations.js is readable
chmod 644 js/translations.js
ls -la js/translations.js

# Test in browser
curl -I https://ibm.a1.bg/js/translations.js
```

Should return `200 OK` not `403 Forbidden`.

## 📋 Checklist

After re-uploading, verify:

- [ ] `.htaccess` uploaded (important for proper routing)
- [ ] All PHP files uploaded (cache, email, config)
- [ ] `js/translations.js` exists and is readable
- [ ] File permissions: 644 for files, 755 for directories
- [ ] No ModSecurity blocking
- [ ] Test: `curl https://ibm.a1.bg/js/translations.js`

## 🆘 Still Getting 403?

### Via cPanel:

1. Go to **File Manager**
2. Navigate to `js/`
3. Right-click `translations.js`
4. Choose **Change Permissions**
5. Set: Owner: Read+Write, Group: Read, World: Read (644)
6. Click **Save**

### Via FTP Client (FileZilla):

1. Connect to your server
2. Navigate to `js/` folder
3. Right-click `translations.js`
4. Choose **File Permissions**
5. Enter: `644`
6. Click **OK**

## 🔧 Nuclear Option: Re-upload Everything

If nothing works:

1. **Delete everything** from server
2. Upload new `deploy-ready.zip` (now includes PHP files and .htaccess)
3. Extract on server
4. Run permission fix:
   ```bash
   find . -type d -exec chmod 755 {} \;
   find . -type f -exec chmod 644 {} \;
   ```

## 📞 Contact Hosting Support

If still broken, contact support with:

> "Hello, I'm getting a 403 Forbidden error on `/js/translations.js`.
> The file exists with correct permissions (644). Can you check if:
> 1. ModSecurity is blocking it
> 2. Any firewall rules blocking .js files
> 3. File ownership is correct
>
> URL: https://ibm.a1.bg/js/translations.js"

---

**Most Common Fix:** `chmod 644 js/translations.js` ✅
