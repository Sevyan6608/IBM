<?php

/**
 * SMTP Configuration File
 * Copy this file and update with your actual SMTP credentials
 * IMPORTANT: Add this file to .gitignore to keep credentials secure
 */

// SMTP Server Configuration
define('SMTP_HOST', 'mail.a1digitalroom.com');     // A1 Digital Room SMTP server
define('SMTP_PORT', 465);                          // Port: 465 for SSL
define('SMTP_USER', 'ibm@a1digitalroom.com');      // SMTP username/email
define('SMTP_PASS', 'y8+p&*Y*KCIN');               // SMTP password
define('SMTP_TO', 'konstantin.tsvetkov@a1.bg, m.manzova@a1.bg, Lyubomir.Levchev@a1.bg, plamen.ruskov@a1.bg');    // Email addresses to receive form submissions

// SMTP Security
define('SMTP_SECURE', 'ssl');                      // SSL for port 465

// Additional Settings
define('SMTP_FROM_NAME', 'IBM A1 Contact Form');   // Sender name
define('SMTP_CHARSET', 'UTF-8');                   // Email charset
